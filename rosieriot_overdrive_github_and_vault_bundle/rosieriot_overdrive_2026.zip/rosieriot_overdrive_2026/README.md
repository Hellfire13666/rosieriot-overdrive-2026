# ROSIERIOT OVERDRIVE 2026
GlitchByte Phantom Labs • Ubuntu/Linux • Python 3

## Install

```bash
mkdir -p "$HOME/PhantomLabsLaunchers"
unzip -n "$HOME/Downloads/rosieriot_overdrive_2026.zip" -d "$HOME/PhantomLabsLaunchers"
bash "$HOME/PhantomLabsLaunchers/rosieriot_overdrive_2026/install_missing_stack.sh"
bash "$HOME/PhantomLabsLaunchers/rosieriot_overdrive_2026/verify_stack.sh"
```

## Offline demo (no network)

```bash
python3 "$HOME/PhantomLabsLaunchers/rosieriot_overdrive_2026/rosieriot_overdrive.py" --target example.com --demo --color always
```

## Authorized live mode

```bash
python3 "$HOME/PhantomLabsLaunchers/rosieriot_overdrive_2026/rosieriot_overdrive.py" --target YOUR_OWN_DOMAIN.com --live --authorized --color always --timeout 55
```

Only scan systems you own or have explicit permission to assess. Default modules: `subfinder,dnsx,httpx`. Extra active stages `naabu,nuclei,aquatone` require selection with `--modules` and their binaries installed. External tools are never downloaded silently.

Output: `~/RosieRiotReports/<domain>_<timestamp>/report.json` and per-module text.

Note: This is a reconstructed working distribution matching the prior project filenames and features, not a byte-for-byte recovered original archive.
